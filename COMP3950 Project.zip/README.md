# Comp3950Project

-To run the simulation, run the file named "main.py" in the folder "Code" using Python 3.6.
-All data will be outputted in the same directory in a text file called "output.txt"
-There is an example test case that was referenced in the write up also in that directory, under the name "bestrun.txt"

Course: COMP3950 
Project

Name                ID
Sachin Rajkumar 	814001729
Sanjay Dookhoo 	    814000842 
Shanea Lewis		809000437
